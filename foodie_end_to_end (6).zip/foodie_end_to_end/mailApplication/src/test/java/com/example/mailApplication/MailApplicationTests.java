package com.example.mailApplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MailApplicationTests {

	@Test
	void contextLoads() {
	}

}
